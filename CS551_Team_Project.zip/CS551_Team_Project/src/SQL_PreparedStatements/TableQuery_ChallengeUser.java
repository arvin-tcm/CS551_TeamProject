/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SQL_PreparedStatements;


/**
 *CREATE TABLE IF NOT EXISTS cs551_team_project.challenge_user
(
    challenge_id BIGINT NOT NULL ,
    user_phone_number VARCHAR(20) NOT NULL,
    user_step BIGINT default 0,
    PRIMARY KEY (challenge_id,user_phone_number),
    FOREIGN KEY (user_phone_number)
        REFERENCES cs551_team_project.user(phone_number)
        ON DELETE CASCADE,
FOREIGN KEY (challenge_id)
        REFERENCES cs551_team_project.challenge(challenge_id)
        ON DELETE CASCADE
);
 * @author Christy Jaeson
 */
public interface TableQuery_ChallengeUser extends DataBaseQuery{
    public static final String TABLE_NAME = "challenge_user";
    public static final String TABLE_COLUMN_NAME_CHALLENGEID = "challenge_id";
    public static final String TABLE_COLUMN_NAME_USERPHONENUMBER= "user_phone_number";
    public static final String TABLE_COLUMN_NAME_USERSTEP = "user_step";
    public static final String INSERT = "INSERT INTO " + DATABASE_NAME + "." + TABLE_NAME 
            + "(" +  TABLE_COLUMN_NAME_CHALLENGEID
            + "," + TABLE_COLUMN_NAME_USERPHONENUMBER
            + ")VALUE (?,?)";
   
    public static final String GET_CHALLENGE_FROM_ID = "SELECT * FROM " + DATABASE_NAME + "." + TABLE_NAME + " WHERE "
            + TABLE_COLUMN_NAME_CHALLENGEID + "=?";   
    public static final String GET_CHALLENGEIDS_FROM_USERNUMBER = "SELECT * FROM " + DATABASE_NAME + "." + TABLE_NAME + " WHERE "
            + TABLE_COLUMN_NAME_USERPHONENUMBER + "=?"; 
    public static final String GET_CHALLENGE_USERS_FROM_USERNUMBER = "SELECT * FROM " + DATABASE_NAME + "." + TABLE_NAME + " WHERE "
            + TABLE_COLUMN_NAME_CHALLENGEID + " IN ("+ "SELECT "+TABLE_COLUMN_NAME_CHALLENGEID+" FROM " + DATABASE_NAME + "." + TABLE_NAME + " WHERE "
            + TABLE_COLUMN_NAME_USERPHONENUMBER + "=?" +")";
}
