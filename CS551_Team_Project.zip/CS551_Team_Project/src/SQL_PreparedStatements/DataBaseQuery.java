/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SQL_PreparedStatements;

/**
 *
 * @author Arvin
 */
public interface DataBaseQuery {

    public static final String URL = "jdbc:mysql://localhost:3306/";
    public static final String USER = "root";
    public static final String PASSWORD = "";//johnson5414";
    public static final String DATABASE_NAME = "CS551_TEAM_PROJECT";
}
