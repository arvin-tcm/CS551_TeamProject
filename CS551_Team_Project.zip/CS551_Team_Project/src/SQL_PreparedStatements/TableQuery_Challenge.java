/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SQL_PreparedStatements;

/**
 *  
 * CREATE TABLE IF NOT EXISTS cs551_team_project.challenge
(
    challenge_id BIGINT NOT NULL AUTO_INCREMENT,
    challengeName VARCHAR(30) NOT NULL,
    start_date dateTime,
    duration int default 1,
    PRIMARY KEY (challenge_id)
);
 *
 * @author User
 */
public interface TableQuery_Challenge extends DataBaseQuery{
    public static final String TABLE_NAME = "Challenge";
    public static final String TABLE_COLUMN_NAME_CHALLENGEID = "challenge_id";
    public static final String TABLE_COLUMN_NAME_CHALLENGENAME = "challengeName";
    public static final String TABLE_COLUMN_NAME_STARTDATE = "start_date";
    public static final String TABLE_COLUMN_NAME_DURATION = "duration";
    
    public static final String INSERT = "INSERT INTO " + DATABASE_NAME + "." + TABLE_NAME 
            + "(" +  TABLE_COLUMN_NAME_CHALLENGENAME
            + "," + TABLE_COLUMN_NAME_STARTDATE
            + "," + TABLE_COLUMN_NAME_DURATION
            + ")VALUE (?,?,?)";
    
    public static final String GET_CHALLENGE_FROM_ID = "SELECT * FROM " + DATABASE_NAME + "." + TABLE_NAME + " WHERE "
            + TABLE_COLUMN_NAME_CHALLENGEID + "=?";   
}
