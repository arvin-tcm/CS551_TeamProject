/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BridgeConnectingService;

import domain.Challenge;
import domain.ImageInBytes;
import domain.OperationCode;
import domain.OperationPackage;
import domain.Post;
import domain.StepRecord;
import domain.UserPackage;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author Arvin
 */
public class BridgeTestClient implements OperationCode {
    
    private final String host = "192.168.56.1";
    private final int port = 8000;
    private ObjectOutputStream toServer;
    private ObjectInputStream fromServer;
    private OperationPackage operation;
    
    public BridgeTestClient() {
        Timestamp start = new Timestamp(115, 6, 15, 18, 40, 0, 0);
        Timestamp end = new Timestamp(115, 6, 15, 21, 45, 0, 0);
        StepRecord step = new StepRecord(200, start, end);
        BufferedImage img = null;
        byte[] bytes = null;
        /*Stack<String> contactList = new Stack<>();
        contactList.push("1");
        contactList.push("3");
        contactList.push("5");
        contactList.push("7");
        contactList.push("9");
        contactList.push("11");
        operation.setContactList(contactList);
        */
        try {
            /*img = ImageIO.read(new File("StarCraft-II-Loading-Screens-HD-Wallpapers_012.jpg"));
            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            
            ImageIO.write(img, "jpg", baos);
            baos.flush();
            
            bytes = baos.toByteArray();
            baos.close();
            
            ImageInBytes image = new ImageInBytes("StarCraft-II-Loading-Screens-HD-Wallpapers_012.jpg",
                    "jpg", Long.valueOf(bytes.length), bytes);
            Post post = new Post("Test Message", image);*/
            UserPackage user = new UserPackage("looooo", "9991" ,null);
            List<UserPackage> users= new ArrayList<UserPackage>();
           // users.add(new UserPackage("","408987",null));
            /*users.add(new UserPackage("","12345",null));
            users.add(new UserPackage("","6667",null));
            Challenge chal=new Challenge("ChallengeNmae:2","07/30/2015",5,users);
            Stack<Challenge> chalList=new Stack<Challenge>();
            chalList.push(chal);
            operation = new OperationPackage(OPERATION_ADD_Challenge, null, null, null,chalList );*/
            operation = new OperationPackage(OPERATION_SEARCH_Challenge, user, null, null,null );
            trace("Client: "+operation.toString());
            //operation.getUserPackage().setPost(post);
            
            Socket socket = new Socket(host, 8000);
            toServer = new ObjectOutputStream(socket.getOutputStream());
            fromServer = new ObjectInputStream(socket.getInputStream());
            
            toServer.writeObject(operation);
            toServer.flush();
            operation = (OperationPackage) fromServer.readObject();
            trace(operation.toString());
          
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(BridgeTestClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private void trace(String s) {
        System.out.println(s);
    }
    
    public static void main(String[] args) {
        new BridgeTestClient();
    }
}
