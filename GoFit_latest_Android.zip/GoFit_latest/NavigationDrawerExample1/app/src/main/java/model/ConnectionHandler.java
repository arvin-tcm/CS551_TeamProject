package model;

import android.os.AsyncTask;
import android.util.Log;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import domain.OperationPackage;

public class ConnectionHandler extends AsyncTask<Void, Void, Void> {

    public static boolean sync=false;
    public static final String host = "172.19.8.159";
    public static final int port = 8000;
    private static ObjectOutputStream toServer;
    private static ObjectInputStream fromServer;
    OperationPackage operation;
    Socket socket;

    public ConnectionHandler(OperationPackage operation){
        this.operation=operation;
    }
    @Override
    protected Void doInBackground(Void... params) {

        try {
            Log.i("AsyncTank", "doInBackgoung: Creating Socket"+operation.toString());
            socket = new Socket(host, port);
            Log.i("AsyncTank", "doInBackgoung: Socket created, Streams assigned");
            toServer = new ObjectOutputStream(socket.getOutputStream());
            Log.i("AsyncTank", "toServer.writeObject(operation);");
            toServer.writeObject(operation);
            toServer.flush();
            Log.i("AsyncTank", "fromServer = new ObjectInputStream(socket.getInputStream());");
            fromServer = new ObjectInputStream(socket.getInputStream());
            operation =(OperationPackage) fromServer.readObject();
            socket.close();
            Log.i("AsyncTank", "sync = f" +operation.toString());
            sync=false;

        } catch (Exception e) {
            Log.i("AsyncTank", "doInBackgoung: Cannot create Socket"+e.getMessage());
        }
        return null;
    }
    public OperationPackage writeObject(OperationPackage operation) {
        try {
            fromServer = new ObjectInputStream(socket.getInputStream());
            toServer = new ObjectOutputStream(socket.getOutputStream());
            Log.i("ConnectionHandler ", operation.toString());
            Log.i("ConnectionHandler ", toServer.toString());
            toServer.writeObject(operation);
            Log.i("ConnectionHandler ", "writeObject()");
            toServer.flush();
            operation =(OperationPackage) fromServer.readObject();
            return operation;
        }catch (Exception ioe){
            Log.i("Error: ", "writeObject IOException "+ioe.getMessage());
        }
        return null;
    }
    public OperationPackage getOperation() {
        return operation;
    }
    public void setOperation(OperationPackage operation) {
        this.operation = operation;
    }
  /*
    public void writeToStream(double lat, double lon) {
        try {
            if (s.isConnected()){
                Log.i("AsynkTask", "writeToStream : Writing lat, lon");
                dos.writeDouble(lat);
                dos.writeDouble(lon);
            } else {
                Log.i("AsynkTask", "writeToStream : Cannot write to stream, Socket is closed");
            }
        } catch (Exception e) {
            Log.i("AsynkTask", "writeToStream : Writing failed");
        }
    }

    public int readFromStream() {
        try {
            if (s.isConnected()) {
                Log.i("AsynkTask", "readFromStream : Reading message");
                message = dis.readInt();
            } else {
                Log.i("AsynkTask", "readFromStream : Cannot Read, Socket is closed");
            }
        } catch (Exception e) {
            Log.i("AsynkTask", "readFromStream : Writing failed");
        }
        return message;
    }
*/
}
