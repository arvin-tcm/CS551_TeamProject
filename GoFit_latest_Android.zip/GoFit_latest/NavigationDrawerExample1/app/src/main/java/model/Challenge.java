package model;

/**
 * Created by User on 7/29/2015.
 */
public class Challenge {
    String ChallengeName;

}
