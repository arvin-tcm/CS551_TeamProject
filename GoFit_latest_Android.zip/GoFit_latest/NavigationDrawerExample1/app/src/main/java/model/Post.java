package model;

import java.util.ArrayList;

/**
 * Created by User on 7/22/2015.
 */
public class Post {


}
