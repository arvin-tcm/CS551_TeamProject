/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author Christy Jaeson
 */
public class Challenge implements Serializable{
    public static final long serialVersionUID = 2L;
    private long challengeId;
    private String challengeName;
    private String startdate;
    private int duration=1;
    private List<UserPackage> userList;

    public Challenge(String startdate,String challengeName,int duration, List<UserPackage> userList){
        this.challengeName=challengeName;
        this.startdate=startdate;
        this.duration=duration;
        this.userList=userList;
    }
    public Challenge(long challengeId,String challengeName,String startdate,int duration, List<UserPackage> userList){
        this.challengeId=challengeId;
        this.challengeName=challengeName;
        this.startdate=startdate;
        this.duration=duration;
        this.userList=userList;
    }
    public long getChallengeId() {
        return challengeId;
    }

    public void setChallengeId(long challengeId) {
        this.challengeId = challengeId;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public int getDuration() {
        return duration;
    }

    public String getChallengeName() {
        return challengeName;
    }

    public void setChallengeName(String challengeName) {
        this.challengeName = challengeName;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public List<UserPackage> getUserList() {
        return userList;
    }

    public void setUserList(List<UserPackage> userList) {
        this.userList = userList;
    }
    @Override
    public String toString() {
        return "Challenge{"
                + "chalId=" + challengeId
                + ", chalName=" + challengeName
                + ", start=" + startdate
                +  ", duration=" + duration
                + ", Users=" + userList + '}';
    }
}
