package background_service;

import android.app.IntentService;
import android.content.Intent;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Binder;
import android.util.Log;
import android.widget.Toast;

import java.sql.Timestamp;
import java.util.Date;

import domain.OperationCode;
import domain.OperationPackage;
import domain.StepRecord;
import domain.UserPackage;
import model.ConnectionHandler;
import model.DatabaseHandler;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p/>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class MyIntentStepService extends IntentService implements SensorEventListener{

    private SensorManager sensorManager;
    boolean isUpdated, isNew = true;
    int stepCount, lastUpdateStepCount;
    Timestamp start = new Timestamp(new Date().getTime()),  end;


    public MyIntentStepService() {
        super("MyIntentStepService");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Toast.makeText(this, "service starting", Toast.LENGTH_SHORT).show();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        return super.onStartCommand(intent, flags, startId);
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        if(isNew){
            lastUpdateStepCount = (int) event.values[0];
            isNew = false;
        }
        stepCount = (int) event.values[0];
        Log.i("vimala",stepCount+"");
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onHandleIntent(Intent intent) {
        // Normally we would do some work here, like download a file.
        // For our sample, we just sleep for 5 seconds.
        long endTime = System.currentTimeMillis() + 10 * 1000;
        DatabaseHandler dh = new DatabaseHandler(this);

        Sensor countSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (countSensor != null) {
            sensorManager.registerListener(this, countSensor, SensorManager.SENSOR_DELAY_UI);
        } else {
            Toast.makeText(this, "Count sensor not available!", Toast.LENGTH_LONG).show();
        }
        while (/*System.currentTimeMillis() < endTime*/true) {
            synchronized (this) {
                try {
                    wait(endTime - System.currentTimeMillis());
                } catch (Exception e) {
                }
            }
            System.out.println(endTime);
            //Timestamp temp = new Timestamp();
            end = new Timestamp(new Date().getTime());
            StepRecord step = new StepRecord(stepCount - lastUpdateStepCount, start, end);
            start = end;
            end = null;
            lastUpdateStepCount = stepCount;
            dh.Update_Step(stepCount); //@ Arvin update the cummulative steps to local database
            //dh.Add_User(new UserPackage("9999"),"");

            UserPackage up = dh.Get_User();
            if(up !=null) {
                up.setStepRecord(step);
                OperationPackage op = new OperationPackage(OperationCode.OPERATION_INSERT_NEW_STEPRECORD, up);
                ConnectionHandler conhandler = new ConnectionHandler(op);
                conhandler.sync = true;
                conhandler.execute();
                Log.i("OperationPackage: ", op.toString());
                Toast.makeText(this, "service running", Toast.LENGTH_SHORT).show();
                Log.i("Info", "Service running");
                endTime = System.currentTimeMillis() + 10 * 1000;
                isNew = true;
            }
        }

    }
    public class MyBinder extends Binder{
        public MyIntentStepService getService(){
            return MyIntentStepService.this;
        }
    }
}
