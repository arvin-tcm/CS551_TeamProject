package com.example.navigationdrawerexample;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Stack;

import domain.ImageInBytes;
import domain.OperationCode;
import domain.OperationPackage;
import domain.Post;
import domain.UserPackage;
import model.ConnectionHandler;
import model.DatabaseHandler;
import model.Movie;

public class ListAdapter_Custom extends BaseAdapter {
	private Activity activity;
	private LayoutInflater inflater;
	private List<Post> postItems;
	//private boolean currentUserFlag=true;
	//private UserPackage anonymousUser;
	private List<Movie> movieItems;
	//ImageLoader imageLoader = AppController.getInstance().getImageLoader();

	public ListAdapter_Custom(Activity activity){

		this.activity = activity;
		UserPackage user=null;
			DatabaseHandler dbHandler =  new DatabaseHandler(this.activity);
			user= dbHandler.Get_User();

		OperationPackage operation = new OperationPackage(OperationCode.OPERATION_GET_POST, user, null, null);
		try {
			ConnectionHandler conhandler = new ConnectionHandler(operation);
			conhandler.sync = true;
			conhandler.execute();
			Log.i("GET POST Return: ", conhandler.sync + "--" + operation.toString());

			while (true) {
				if (conhandler.sync == false) {
					operation = conhandler.getOperation();
					Log.i("in  while return value ", conhandler.sync + "--" + operation.toString());
					break;
				} else {
					continue;
				}
			}
		}catch (Exception e){

		}
		this.postItems=new ArrayList<Post>();
		Stack<Post> postList=operation.getPostList();
		if(postList!=null)
		for(;postList.isEmpty()==false;) {
			postItems.add(postList.pop());
		}
	}
	public ListAdapter_Custom(Activity activity, UserPackage usertemp){

		this.activity = activity;
		UserPackage user=usertemp;

		OperationPackage operation = new OperationPackage(OperationCode.OPERATION_GET_POST, user, null, null);
		try {
			ConnectionHandler conhandler = new ConnectionHandler(operation);
			conhandler.sync = true;
			conhandler.execute();
			Log.i("GET POST Return: ", conhandler.sync + "--" + operation.toString());

			while (true) {
				if (conhandler.sync == false) {
					operation = conhandler.getOperation();
					Log.i("in  while return value ", conhandler.sync + "--" + operation.toString());
					break;
				} else {
					continue;
				}
			}
		}catch (Exception e){

		}
		this.postItems=new ArrayList<Post>();
		Stack<Post> postList=operation.getPostList();
		if(postList!=null)
			for(;postList.isEmpty()==false;) {
				postItems.add(postList.pop());
			}
	}

	public ListAdapter_Custom(Activity activity, List<Post> postItems) {
		this.activity = activity;
		this.postItems = postItems;
	}

	@Override
	public int getCount() {
		return postItems.size();
	}

	@Override
	public Object getItem(int location) {
		return postItems.get(location);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		if (inflater == null)
			inflater = (LayoutInflater) activity
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		if (convertView == null)
			convertView = inflater.inflate(R.layout.post_row_list, null);

		Post post= postItems.get(position);

		TextView title = (TextView) convertView.findViewById(R.id.postList_message);
		TextView rating = (TextView) convertView.findViewById(R.id.postList_other);
		TextView year = (TextView) convertView.findViewById(R.id.postList_time);

		title.setText(post.getMessage());
		rating.setText(post.getImageInBytes().getImageFileName());
		year.setText(post.getTime());
		ImageView thumbNail=(ImageView)convertView.findViewById(R.id.postList_image);
		Bitmap bmp=BitmapFactory.decodeByteArray(post.getImageInBytes().getImageData(),0,post.getImageInBytes().getImageData().length);
		thumbNail.setImageBitmap(bmp);
		return convertView;
	}
}