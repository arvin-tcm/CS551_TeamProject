package com.example.navigationdrawerexample;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import domain.UserPackage;
import model.DatabaseHandler;
import model.Movie;

/**
 * Created by User on 7/16/2015.
 */
public class HomeActivity extends Fragment {

    private static final String url = "http://api.androidhive.info/json/movies.json";
    private ProgressDialog pDialog;
    private List<Movie> movieList = new ArrayList<Movie>();
    private ListView listView;
    private ListAdapter_Custom adapter;
    private TextView profileName,profileNumber;
    UserPackage userDetails=null;

    public void setUserDetails(UserPackage userDetails) {
        this.userDetails = userDetails;
    }

    public HomeActivity() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.home_activity, container, false);
        UserPackage user=null;
        if(userDetails==null) {
            DatabaseHandler dbHandler = new DatabaseHandler(getActivity());
            user = dbHandler.Get_User();
            getActivity().setTitle("Home Page");
            Log.i("in home:", user.toString());
        }else{
            user = userDetails;
            getActivity().setTitle("Viewing "+userDetails.getUserName()+"'s Home");
            Log.i("in home:", userDetails.getUserName());
        }


        profileName=(TextView) rootView.findViewById(R.id.profile_name);
        profileName.setText(user.getUserName());

        profileNumber=(TextView) rootView.findViewById(R.id.profile_number);
        profileNumber.setText(user.getPhoneNumber());
        if(userDetails==null) {
            ImageView imageView = (ImageView) rootView.findViewById(R.id.thumbnail);
            String picPath = user.getImageInBytes().getImageFileName();
            Log.i("img==>", picPath);
            imageView.setImageBitmap(BitmapFactory.decodeFile(picPath));
        }
        listView = (ListView) rootView.findViewById(R.id.list);
        if(userDetails==null)
            adapter = new ListAdapter_Custom(getActivity());
        else
            adapter = new ListAdapter_Custom(getActivity(),userDetails);
        listView.setAdapter(adapter);

        return rootView;
    }


}
