package com.example.navigationdrawerexample;

import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import domain.Challenge;
import domain.OperationCode;
import domain.OperationPackage;
import domain.UserPackage;
import model.ConnectionHandler;
import model.DatabaseHandler;

/**
 * Created by User on 7/28/2015.
 */
public class CreateChallenge extends Fragment {
    private ListView listView;
    private ListAdapter_ChallengeContact adapter;

    public CreateChallenge() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.challenge_contacts, container, false);

        final EditText chal_name=(EditText)rootView.findViewById(R.id.challenge_name);

        final Button dataPick = (Button)rootView.findViewById(R.id.challenge_date);
        dataPick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getActivity().getFragmentManager(), "datePicker");
            }
        });
        Button create = (Button)rootView.findViewById(R.id.challenge_create);
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                int size=listView.getCount();
                Challenge challenge=null;
                List<UserPackage> userList=new ArrayList<UserPackage>();

                for(int i=0;i<size;i++) {
                    UserPackage user=(UserPackage)adapter.getItem(i);
                    Log.i("-------",adapter.getItem(i).toString());
                    if(user.getUserId()==1){
                        userList.add(user);
                    }
                }
                DatabaseHandler dbHandler=new DatabaseHandler(getActivity());
                userList.add(dbHandler.Get_User());
                challenge= new Challenge(dataPick.getText().toString(),chal_name.getText().toString(),1,userList);
                Log.i("-------", challenge.toString());

                Stack<Challenge> challengeList=new Stack<Challenge>();
                challengeList.push(challenge);
                OperationPackage operation= new OperationPackage(OperationCode.OPERATION_ADD_Challenge,null, null,null,challengeList);
                Log.i("ChallengeCreate :", operation.toString());
                ConnectionHandler conhandler = new ConnectionHandler(operation);
                conhandler.execute();
                /*Fragment fragment = new ChallengeActivity();
                FragmentManager fragmentManager = getActivity().getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();*/
                BlankActivity blk= new BlankActivity();
                blk.setStr("Your Challenge is Created");
                Fragment fragment =blk;
                FragmentManager fragmentManager = getActivity().getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();

            }
        });
        listView = (ListView) rootView.findViewById(R.id.challenge_contactsList);
        adapter = new ListAdapter_ChallengeContact(getActivity());
        //adapter.setCheckbox(true);
        listView.setAdapter(adapter);
        return rootView;
    }
}
