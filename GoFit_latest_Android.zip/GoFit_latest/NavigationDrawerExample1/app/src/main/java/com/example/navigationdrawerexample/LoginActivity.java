package com.example.navigationdrawerexample;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
//import java.awt.image.BufferedImage;
import java.net.Socket;

//import javax.imageio.ImageIO;
import background_service.MyIntentStepService;
import domain.ImageInBytes;
import domain.OperationCode;
import domain.OperationPackage;
import domain.UserPackage;
import model.ConnectionHandler;
import model.DatabaseHandler;


/**
 * Created by User on 7/25/2015.
 */
public class LoginActivity extends Fragment {

    public static final String host = "192.168.56.1";
    public static final int port = 8000;
    private ObjectOutputStream toServer;
    private ObjectInputStream fromServer;
    private OperationPackage operation;

    DatabaseHandler dbHandler = new DatabaseHandler(getActivity());

    private static String picturePath="";
    private static int RESULT_LOAD_IMAGE = 1;
    EditText userName, userNumber;
    Button Login;
    public LoginActivity() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.login_activity, container, false);
        ImageView profilePictureLoad = (ImageView) rootView.findViewById(R.id.profileImage);
        Login = (Button) rootView.findViewById(R.id.userLogin);
        profilePictureLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent i = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });

        userName= (EditText) rootView.findViewById(R.id.userName);
        userNumber= (EditText) rootView.findViewById(R.id.userNumber);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                operation=null;

                if(validate_feild(userName) &&  validate_feild(userNumber)) {
                    ImageInBytes image=null;
                    try {
                        Log.i("Login Activity", "PicPath=" + picturePath);
                        String filepath = picturePath;
                        File imagefile = new File(filepath);
                        FileInputStream fis = null;

                        fis = new FileInputStream(imagefile);

                        int newWidth = 100, newHeight = 100;
                        //yourBitmap, newWidth, newHeight, true);
                        Bitmap bm = Bitmap.createScaledBitmap(BitmapFactory.decodeStream(fis), newWidth, newHeight, true);
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                        byte[] bytes = baos.toByteArray();
                        baos.close();


                        String filename[] = picturePath.split("/");
                        image = new ImageInBytes(filename[filename.length - 1],
                                "jpg", Long.valueOf(bytes.length), bytes);
                    }catch (IOException ioe){
                        Log.e("Login Activity", "Error Loading..." + picturePath);

                    }
                    UserPackage user = new UserPackage(userName.getText().toString(), userNumber.getText().toString(),image);

                    trace("Log: " + userName.getText().toString() + "--" + userNumber.getText().toString());
                    operation = new OperationPackage(OperationCode.OPERATION_SEARCH_ADD_USER, user, null, null);
                    trace("Log: " + operation.toString());
                    try {
                        ConnectionHandler conhandler = new ConnectionHandler(operation);
                        conhandler.sync=true;
                         conhandler.execute();
                        Toast.makeText(getActivity(), "Connecting to Server...", Toast.LENGTH_SHORT);
                        trace("Log return from search: " +conhandler.sync+"--"+operation.toString());

                        while(true) {
                       //     trace("in  while ");
                            if (conhandler.sync == false) {
                                operation = conhandler.getOperation();
                                trace("in  while " +conhandler.sync+"--"+operation.toString());
                                break;
                            }
                            else {
                                continue;
                            }
                        }
                        conhandler=null;
                        //store operation in local database
                        DatabaseHandler dbHandler =  new DatabaseHandler(getActivity());
                        dbHandler.Add_User(operation.getUserPackage(),picturePath);
                        dbHandler.close();;
                        trace("Log: " +operation.toString());
                    } catch (Exception e) {
                        trace("Error: " + e.toString());
                        Toast.makeText(getActivity(), "Error connecting to server... Try Again later", Toast.LENGTH_LONG);
                    }
                    Fragment fragment = new HomeActivity();
                    FragmentManager fragmentManager = getActivity().getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();

                }
                Intent intent  = new Intent(getActivity(), MyIntentStepService.class);
                getActivity().startService(intent);
            }
            public boolean validate_feild(EditText edt){
                boolean flag = true;
                if(edt.getId()==R.id.userNumber){
                    try {
                        Integer.parseInt(edt.getText().toString());
                    }catch (Exception e){
                        edt.setError("Numbers Only");
                        flag=false;
                    }
                }
                if(edt.getText().toString().length()<=0){
                    edt.setError("Enter "+edt.getHint());//, Drawable.createFromPath(R.drawable.ic_error) );
                    flag=false;
                }

                return flag;
            }
        });
        return rootView;
    }
    private void trace(String str) {
        Log.v("Server ", str);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(getActivity().getApplicationContext(), requestCode + " # " + resultCode + " # " + data, Toast.LENGTH_SHORT).show();

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == Activity.RESULT_OK && data != null) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };


            Cursor cursor = getActivity().getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
             picturePath = cursor.getString(columnIndex);
            Toast.makeText(getActivity().getApplicationContext(),
                    "Path"+picturePath, Toast.LENGTH_LONG).show();
            cursor.close();

            ImageView imageView = (ImageView) getActivity().findViewById(R.id.profileImage);
            imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));

        }


    }
}
