package com.example.navigationdrawerexample;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import domain.ImageInBytes;
import domain.OperationCode;
import domain.OperationPackage;
import domain.Post;
import domain.UserPackage;
import model.ConnectionHandler;
import model.DatabaseHandler;

/**
 * Created by User on 7/16/2015.
 */
public class PostActivity  extends Fragment {

    private static int RESULT_LOAD_IMAGE = 1;
    //ImageView mImageView ;
    String imgDecodableString;
    private ImageView imageView;
    private EditText PostMsg;
    private String  picturePath;
    DatabaseHandler dbHandler;
    public PostActivity() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.post_activity, container, false);
        Button buttonPost= (Button) rootView.findViewById(R.id.updatePost);
        PostMsg=(EditText) rootView.findViewById(R.id.postMsg);
        dbHandler=new DatabaseHandler(getActivity());
        Button buttonLoadImage = (Button) rootView.findViewById(R.id.loadFromGallery);
        buttonLoadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent i = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });
        buttonPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                try {
                    Log.i("Post Activity","PicPath="+picturePath);
                String filepath = picturePath;
                File imagefile = new File(filepath);
                FileInputStream fis = null;

                    fis = new FileInputStream(imagefile);

                    int newWidth=100,newHeight=100;
                    //yourBitmap, newWidth, newHeight, true);
                Bitmap bm = Bitmap.createScaledBitmap(BitmapFactory.decodeStream(fis),newWidth, newHeight, true);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] bytes = baos.toByteArray();
                baos.close();

                    String filename[]= picturePath.split("/");
                    ImageInBytes image = new ImageInBytes(filename[filename.length-1],
                        "jpg", Long.valueOf(bytes.length), bytes);
                    Post post = new Post(PostMsg.getText().toString(), image);
                    UserPackage user= dbHandler.Get_User();
                    Log.i("Post Activity :", user.toString());
                    OperationPackage operation= new OperationPackage(OperationCode.OPERATION_ADD_POST,user, null,null);
                    operation.getUserPackage().setPost(post);
                    Log.i("Post Activity :", operation.toString());
                    Toast.makeText(getActivity().getApplicationContext(), "   Message Posted.  ", Toast.LENGTH_LONG).show();
                    ConnectionHandler conhandler = new ConnectionHandler(operation);
                    conhandler.execute();

                    /*Fragment fragment =new HomeActivity();
                    FragmentManager fragmentManager = getActivity().getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();
*/
                    BlankActivity blk= new BlankActivity();
                    blk.setStr("Your message is Posted");
                    Fragment fragment =blk;
                    FragmentManager fragmentManager = getActivity().getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();

                } catch (Exception e) {
                    Log.e("Post Activity", "Post: " + e.getMessage());

                }

            }
        });
        return rootView;
    }

    private void postUpdate() {

    }
    ///////////////////type1
   /* public void loadImagefromGallery(View view) {
        Intent i = new Intent(
                Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(i, RESULT_LOAD_IMAGE);
    }*/

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //Toast.makeText(getActivity().getApplicationContext(), requestCode+" # "+resultCode+" # "+data, Toast.LENGTH_SHORT).show();

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == Activity.RESULT_OK && data != null) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };


            Cursor cursor = getActivity().getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
             picturePath = cursor.getString(columnIndex);
            Log.i("path=> ",picturePath);
           // Toast.makeText(getActivity().getApplicationContext(),"Path"+picturePath, Toast.LENGTH_LONG).show();
            cursor.close();

             imageView = (ImageView) getActivity().findViewById(R.id.postImage);
            imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));

        }


    }

}