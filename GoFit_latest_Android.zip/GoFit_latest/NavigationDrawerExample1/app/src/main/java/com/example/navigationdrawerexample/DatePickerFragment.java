package com.example.navigationdrawerexample;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.DatePicker;

import java.util.Calendar;

public class DatePickerFragment extends DialogFragment
        implements DatePickerDialog.OnDateSetListener {

    int year,month,day;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current date as the default date in the picker
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    public void onDateSet(DatePicker view, int year, int month, int day) {
        Log.i("DatePicker: ",""+year+month+day);
        Button datepick= (Button)getActivity().findViewById(R.id.challenge_date);
        datepick.setText(this.getDate(day,month+1,year));
    }
    public String getDate(int day, int month,int year) {
        String sday=""+day, smonth=""+month,syear=""+year;
        String str="";

        if(sday.length()<2)
            sday= "0"+sday;
        if(smonth.length()<2)
            smonth= "0"+smonth;

        str=smonth+"/"+sday+"/"+syear;
        return str;
    }
    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
}