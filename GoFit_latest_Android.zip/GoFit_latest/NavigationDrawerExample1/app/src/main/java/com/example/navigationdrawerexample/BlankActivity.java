package com.example.navigationdrawerexample;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by User on 8/4/2015.
 */
public class BlankActivity extends Fragment {
    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    String str=null;
    public BlankActivity() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.toast_activity, container, false);
        TextView txt=(TextView)rootView.findViewById(R.id.toastMsg);
        txt.setText(str);
        return rootView;
    }

}
