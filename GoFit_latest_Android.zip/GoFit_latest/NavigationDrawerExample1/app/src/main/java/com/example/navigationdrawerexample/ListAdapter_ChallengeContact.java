package com.example.navigationdrawerexample;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import domain.ImageInBytes;
import domain.OperationCode;
import domain.OperationPackage;
import domain.UserPackage;
import model.ConnectionHandler;
import model.DatabaseHandler;

/**
 * Created by User on 7/28/2015.
 */
public class ListAdapter_ChallengeContact extends BaseAdapter {
    private Activity activity;
    private LayoutInflater inflater;
    private List<UserPackage> userItems;
    private List<Boolean> checkedItems;

    //ImageLoader imageLoader = AppController.getInstance().getImageLoader();

    public ListAdapter_ChallengeContact(Activity activity){

        this.activity = activity;
        //final ArrayList<String> contList = new ArrayList<String>();
        //Stack<String> contactStack = new Stack<String>();
        //contactStack.push("12345");
        //contactStack.push("6667");
        this.userItems=new ArrayList<UserPackage>();
        DatabaseHandler dbHandler =  new DatabaseHandler(activity);
        List<String> temp=dbHandler.Get_Contacts();
        dbHandler.close();

        ContentResolver cr = activity.getContentResolver();
        String[] projection = new String[] {
                ContactsContract.PhoneLookup.DISPLAY_NAME,
                ContactsContract.PhoneLookup._ID,
                ContactsContract.PhoneLookup.PHOTO_URI};
        String   name=null;
        String id;
        ImageInBytes img=null;
        for(String num: temp) {

            // encode the phone number and build the filter URI
            Uri contactUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num));
            //
            Uri photoUri = Uri.withAppendedPath(contactUri, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY);
            // query time
            Cursor cursor = activity.getContentResolver().query(contactUri, projection, null, null, null);

            if(cursor != null) {
                if (cursor.moveToFirst()) {
                    name=cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));

                    id=cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup._ID));
                    contactUri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, String.valueOf(id));
                    InputStream photo_stream = ContactsContract.Contacts.openContactPhotoInputStream(cr, contactUri, true);
                    if (photo_stream!=null) {
                        BufferedInputStream buf = new BufferedInputStream(photo_stream);
                        Bitmap my_btmp = BitmapFactory.decodeStream(buf);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        my_btmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        img = new ImageInBytes(null, "jpg", Long.valueOf(byteArray.length), byteArray);
                        try {
                            buf.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    Log.d("Contact Found @ ", num);
                    Log.d("Contact name  = ", name);

                } else {
                    Log.d("Contact Not Found @ ", num);
                }

            }
            userItems.add(new UserPackage(name, num, img));
            img=null;
            cursor.close();
        }
        /*ContentResolver cr = activity.getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);
        if (cur.getCount() > 0) {
            while (cur.moveToNext()) {
                String id = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                if (Integer.parseInt(cur.getString(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    Cursor pCur = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = ?",
                            new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        Log.d("Phone Contact details", pCur.getString(0));
                        String number = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        contactStack.add(number.replaceAll("[^a-zA-Z0-9]",""));
                        String projection = name;
                        contList.add(name);
                        projection =number;
                        contList.add(number);
                    }

                    pCur.close();
                }
            }
        }
        cur.close();

        OperationPackage cpackage = new OperationPackage(OperationCode.OPERATION_SEARCH_CONTACT_LIST,null,contactStack,null);

        try {
            ConnectionHandler conhandler = new ConnectionHandler(cpackage);
            conhandler.sync=true;
            conhandler.execute();


            while(true) {
                //     trace("in  while ");
                if (conhandler.sync == false) {
                    cpackage = conhandler.getOperation();
                    break;
                }
                else {
                    continue;
                }
            }
        } catch (Exception e) {
            Log.d("Error: " , e.toString());
            Toast.makeText(activity, "Error connecting to server... Try Again later", Toast.LENGTH_LONG);
        }

        this.userItems=new ArrayList<UserPackage>();
        if(cpackage!=null)
            for(;cpackage.getContactList().isEmpty()==false;)
                userItems.add(new UserPackage("namae", cpackage.getContactList().pop(),null ));
    */}

    public ListAdapter_ChallengeContact(Activity activity, int layoutID){
        this.activity = activity;
        final ArrayList<String> contList = new ArrayList<String>();
        Stack<String> contactStack = new Stack<String>();
        //contactStack.push("12345");
        //contactStack.push("6667");
        ContentResolver cr = activity.getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);
        if (cur.getCount() > 0) {
            while (cur.moveToNext()) {
                String id = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                if (Integer.parseInt(cur.getString(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    Cursor pCur = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = ?",
                            new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        Log.d("Phone Contact details", pCur.getString(0));
                        String number = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        contactStack.add(number.replaceAll("[^a-zA-Z0-9]",""));
                        String projection = name;
                        contList.add(name);
                        projection =number;
                        contList.add(number);
                    }

                    pCur.close();
                }
            }
        }
        cur.close();

        OperationPackage cpackage = new OperationPackage(OperationCode.OPERATION_SEARCH_CONTACT_LIST,null,contactStack,null);

        try {
            ConnectionHandler conhandler = new ConnectionHandler(cpackage);
            conhandler.sync=true;
            conhandler.execute();


            while(true) {
                //     trace("in  while ");
                if (conhandler.sync == false) {
                    cpackage = conhandler.getOperation();
                    break;
                }
                else {
                    continue;
                }
            }
        } catch (Exception e) {
            Log.d("Error: " , e.toString());
            Toast.makeText(activity, "Error connecting to server... Try Again later", Toast.LENGTH_LONG);
        }

        this.userItems=new ArrayList<UserPackage>();
        if(cpackage!=null)
            for(;cpackage.getContactList().isEmpty()==false;)
                userItems.add(new UserPackage("namae", cpackage.getContactList().pop(),null ));
    }

    @Override
    public int getCount() {
        return userItems.size();
    }

    @Override
    public Object getItem(int location) {
        return userItems.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.challenge_contact_rowlist, null);

        UserPackage user= userItems.get(position);

       // checkedItems.add(false);
        TextView name = (TextView) convertView.findViewById(R.id.ccontactList_Name);
        TextView number = (TextView) convertView.findViewById(R.id.ccontactList_Number);
        name.setText(user.getUserName());
        number.setText(user.getPhoneNumber());
        CheckBox chk=(CheckBox)convertView.findViewById(R.id.checkBox1);
        chk.setOnCheckedChangeListener
                (new CompoundButton.OnCheckedChangeListener() {
                     @Override
                     public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                         if (isChecked)
                             userItems.get(position).setUserId(1);
                         else
                             userItems.get(position).setUserId(0);
                     }
                 }
                );
        if(user.getImageInBytes()!=null){
            ImageView thumbNail=(ImageView)convertView.findViewById(R.id.ccontactList_img);
            Bitmap bmp=BitmapFactory.decodeByteArray(user.getImageInBytes().getImageData(),0,user.getImageInBytes().getImageData().length);
            thumbNail.setImageBitmap(bmp);
        } return convertView;
    }

}