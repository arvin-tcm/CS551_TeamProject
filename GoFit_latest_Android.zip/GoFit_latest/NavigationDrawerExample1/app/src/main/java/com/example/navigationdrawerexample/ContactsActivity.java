package com.example.navigationdrawerexample;

import android.app.Activity;
import android.app.Fragment;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Stack;

import domain.OperationCode;
import domain.OperationPackage;
import domain.UserPackage;
import model.ConnectionHandler;
import model.DatabaseHandler;

public class ContactsActivity extends Fragment {

    private Activity activity;
    private ListView listView;
    private ListAdapter_Contacts adapter;
    ImageView refresh;
    public ContactsActivity() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.contact_activity, container, false);

        activity=getActivity();
        refresh=(ImageView) rootView.findViewById (R.id.refresh_contacts);
        listView = (ListView) rootView.findViewById(R.id.contact_list);
        adapter = new ListAdapter_Contacts(getActivity());
        listView.setAdapter(adapter);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                final ArrayList<String> contList = new ArrayList<String>();
                Stack<String> contactStack = new Stack<String>();
                ContentResolver cr = activity.getContentResolver();
                Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                        null, null, null, null);
                if (cur.getCount() > 0) {
                    while (cur.moveToNext()) {
                        String id = cur.getString(
                                cur.getColumnIndex(ContactsContract.Contacts._ID));
                        String name = cur.getString(
                                cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                        if (Integer.parseInt(cur.getString(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                            Cursor pCur = cr.query(
                                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                    null,
                                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                                    new String[]{id}, null);
                            while (pCur.moveToNext()) {
                                Log.d("Phone Contact details", pCur.getString(0));
                                String number = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                                contactStack.add(number.replaceAll("[^a-zA-Z0-9]", ""));
                                String projection = name;
                                contList.add(name);
                                projection = number;
                                contList.add(number);
                            }
                            pCur.close();
                        }
                    }
                }
                cur.close();
                OperationPackage cpackage = new OperationPackage(OperationCode.OPERATION_SEARCH_CONTACT_LIST, null, contactStack, null);
                try {
                    ConnectionHandler conhandler = new ConnectionHandler(cpackage);
                    conhandler.sync = true;
                    conhandler.execute();
                    while (true) {
                        if (conhandler.sync == false) {
                            cpackage = conhandler.getOperation();
                            break;
                        } else {
                            continue;
                        }
                    }
                } catch (Exception e) {
                    Log.d("Error: ", e.toString());
                    Toast.makeText(activity, "Error connecting to server... Try Again later", Toast.LENGTH_LONG);
                }
                DatabaseHandler dbHandler = new DatabaseHandler(getActivity());
                if (cpackage != null)
                    for (; cpackage.getContactList().isEmpty() == false; )
                        dbHandler.Add_Contact(cpackage.getContactList().pop());
                dbHandler.close();
                adapter = new ListAdapter_Contacts(getActivity());
                listView.setAdapter(adapter);

            }
        });
        return rootView;
    }

}
