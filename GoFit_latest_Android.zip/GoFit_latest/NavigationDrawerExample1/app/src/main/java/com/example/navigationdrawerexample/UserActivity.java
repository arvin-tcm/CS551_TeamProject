package com.example.navigationdrawerexample;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import background_service.MyIntentStepService;
import model.DatabaseHandler;

/**
 * Created by User on 7/16/2015.
 */
public class UserActivity extends Fragment {
static int i=0;

    public UserActivity() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.user_activity, container, false);

        if(i==0){
            Log.i("starting inteng",i+":i=========");
            Intent intent  = new Intent(getActivity(), MyIntentStepService.class);
            getActivity().startService(intent);
            i=1;
        }
        DatabaseHandler dh=new DatabaseHandler(getActivity());

        TextView txt=(TextView)rootView.findViewById(R.id.steps);
        txt.setText(""+dh.Get_Step());
        return rootView;
    }

}
