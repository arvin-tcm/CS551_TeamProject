package com.example.navigationdrawerexample;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

import domain.UserPackage;

/**
 * Created by User on 8/9/2015.
 */
public class Chalenge extends Fragment {
    private ListAdapter_ChallengeUsers adapter;
    private ListView listView;
    List<UserPackage> users;
    private String _title;
    private String _date;
    private String _contact;

    public void setTitle(String title) {
        this._title = title;
    }
    public void set_contact(String _contact) { this._contact = _contact;  }
    public void set_date(String _date) { this._date = _date; }

    public Chalenge() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.challenge_each, container, false);
        getActivity().setTitle("Challenge:"+_title);
        TextView name=(TextView)rootView.findViewById(R.id.chal_name_each);
        TextView date=(TextView)rootView.findViewById(R.id.chal_date_each);
        name.setText(_title);
        date.setText(_date);
        listView = (ListView) rootView.findViewById(R.id.chal_each_users);
        adapter = new ListAdapter_ChallengeUsers(getActivity(),_contact);
        listView.setAdapter(adapter);
        return rootView;
    }
}