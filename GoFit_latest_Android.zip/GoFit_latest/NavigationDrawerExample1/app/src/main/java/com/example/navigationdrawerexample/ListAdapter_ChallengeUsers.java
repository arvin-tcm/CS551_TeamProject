package com.example.navigationdrawerexample;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import domain.ImageInBytes;
import domain.UserPackage;
import model.DatabaseHandler;

/**
 * Created by User on 7/28/2015.
 */
public class ListAdapter_ChallengeUsers extends BaseAdapter {
    private Activity activity;
    private LayoutInflater inflater;
    private List<UserPackage> userItems;
    private UserPackage u;
    public ListAdapter_ChallengeUsers(Activity activity, String abc){

        this.activity = activity;
        this.userItems=new ArrayList<UserPackage>();
        DatabaseHandler dbHandler =  new DatabaseHandler(activity);
        u=dbHandler.Get_User();
        dbHandler.close();
        Log.i("CHU_User:",u.toString());
        String[] temp=abc.split(",");
        ContentResolver cr = activity.getContentResolver();
        String[] projection = new String[] {
                ContactsContract.PhoneLookup.DISPLAY_NAME,
                ContactsContract.PhoneLookup._ID,
                ContactsContract.PhoneLookup.PHOTO_URI};
        String   name=null;
        String id;
        ImageInBytes img=null;
        for(String num: temp) {

            // encode the phone number and build the filter URI
            Uri contactUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num));
            //
            Uri photoUri = Uri.withAppendedPath(contactUri, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY);
            // query time
            Cursor cursor = activity.getContentResolver().query(contactUri, projection, null, null, null);

            if(cursor != null) {
                if (cursor.moveToFirst()) {
                    name=cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));

                    id=cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup._ID));
                    contactUri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, String.valueOf(id));
                    InputStream photo_stream = ContactsContract.Contacts.openContactPhotoInputStream(cr, contactUri, true);
                    if (photo_stream!=null) {
                        BufferedInputStream buf = new BufferedInputStream(photo_stream);
                        Bitmap my_btmp = BitmapFactory.decodeStream(buf);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        my_btmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        img = new ImageInBytes(null, "jpg", Long.valueOf(byteArray.length), byteArray);
                        try {
                            buf.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    Log.d("Contact Found @ ", num);
                    Log.d("Contact name  = ", name);

                } else {
                    Log.d("Contact Not Found @ ", num);
                    name="Anonymous";
                    if(num.equals(u.getPhoneNumber())){
                        Log.d("Contactinside name  = ", name);
                        name=u.getUserName();
                    }
                    Log.d("Contact name  = ", name);
                }

            }
            userItems.add(new UserPackage(name, num, img));
            img=null;
            name="";
            cursor.close();
        }
    }

    @Override
    public int getCount() {
        return userItems.size();
    }

    @Override
    public Object getItem(int location) {
        return userItems.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.contacts_rowlist, null);

        UserPackage user= userItems.get(position);

        TextView name = (TextView) convertView.findViewById(R.id.contactList_Name);
        TextView number = (TextView) convertView.findViewById(R.id.contactList_Number);

        name.setText(user.getUserName());
        number.setText(user.getPhoneNumber());
        ImageView thumbNail=(ImageView)convertView.findViewById(R.id.contactList_img);
        if(user.getImageInBytes()!=null){
            Bitmap bmp=BitmapFactory.decodeByteArray(user.getImageInBytes().getImageData(), 0, user.getImageInBytes().getImageData().length);
            thumbNail.setImageBitmap(bmp);
        }
        return convertView;
    }

}