package com.example.navigationdrawerexample;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import domain.Challenge;
import domain.OperationCode;
import domain.OperationPackage;
import domain.UserPackage;
import model.ConnectionHandler;
import model.DatabaseHandler;

/**
 * Created by User on 7/29/2015.
 */
public class ListAdapter_Challenge extends BaseAdapter {
    private Activity activity;
    private LayoutInflater inflater;
    private List<Challenge> challengeItems;

    public ListAdapter_Challenge(Activity activity){

        this.activity = activity;
        DatabaseHandler dbHandler =  new DatabaseHandler(this.activity);
        UserPackage user= dbHandler.Get_User();

        OperationPackage operation = new OperationPackage(OperationCode.OPERATION_SEARCH_Challenge, user, null, null, null);
        try {
            ConnectionHandler conhandler = new ConnectionHandler(operation);
            conhandler.sync = true;
            conhandler.execute();
            Log.i("GET POST Return: ", conhandler.sync + "--" + operation.toString());

            while (true) {
                if (conhandler.sync == false) {
                    operation = conhandler.getOperation();
                    Log.i("in  while return value ", conhandler.sync + "--" + operation.toString());
                    break;
                } else {
                    continue;
                }
            }
        }catch (Exception e){

        }
        this.challengeItems=new ArrayList<Challenge>();
        Stack<Challenge> chalList=operation.getChallengeList();
        if(chalList!=null)
            for(;chalList.isEmpty()==false;) {
                challengeItems.add(chalList.pop());
            }
    }

    public ListAdapter_Challenge(Activity activity, List<Challenge> challengeItems) {
        this.activity = activity;
        this.challengeItems = challengeItems;
    }

    @Override
    public int getCount() {
        return challengeItems.size();
    }

    @Override
    public Object getItem(int location) {
        return challengeItems.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        DatabaseHandler dbHandler =  new DatabaseHandler(this.activity);

        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.challenge_rowlist, null);
            convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Chalenge hme=new Chalenge();
                Challenge ch=challengeItems.get(position);

                hme.setTitle(ch.getChallengeName());
                hme.set_date(ch.getStartdate());

                List<UserPackage> users=ch.getUserList();
                int size=users.size();
                String str="";
                for(int i=0;i<size;i++)
                    str=str+users.get(i).getPhoneNumber()+",";
                Log.i("==>",str);
                hme.set_contact(str.substring(0,str.length()-1));
                Fragment fragment =hme;
                FragmentManager fragmentManager = activity.getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();
            }
        });

        Challenge challenge= challengeItems.get(position);

        TextView title = (TextView) convertView.findViewById(R.id.chalList_Name);
        TextView start = (TextView) convertView.findViewById(R.id.chalList_start);
        TextView contacts = (TextView) convertView.findViewById(R.id.chalList_contacts);

        title.setText(challenge.getChallengeName());
        start.setText(challenge.getStartdate());
        String str="UserList: ";
        String[] projection = new String[] {
                ContactsContract.PhoneLookup.DISPLAY_NAME,
                ContactsContract.PhoneLookup._ID,
                ContactsContract.PhoneLookup.PHOTO_URI
        };
        for(int i=0;i<challenge.getUserList().size();i++) {
            Uri contactUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(challenge.getUserList().get(i).getPhoneNumber()));
            Cursor cursor = activity.getContentResolver().query(contactUri, projection, null, null, null);
            if (cursor != null) {
                String name = "";
                if (cursor.moveToFirst()) {
                    name = cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));
                    //id=cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup._ID));
                } else //changes-umai
                    if(challenge.getUserList().get(i).getPhoneNumber().equals(dbHandler.Get_User().getPhoneNumber())) {
                        name = dbHandler.Get_User().getUserName();
                    }else {
                    name="Anonymous_"+ challenge.getUserList().get(i).getPhoneNumber();
                    Log.d("Contact Not Found @ ", challenge.getUserList().get(i).getPhoneNumber());
                }
                str = str + "[ "  + name + "] ";
            }
            cursor.close();
        }
        contacts.setText(str);
        return convertView;
    }
}