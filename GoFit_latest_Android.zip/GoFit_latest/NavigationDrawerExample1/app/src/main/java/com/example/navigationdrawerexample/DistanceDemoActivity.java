package com.example.navigationdrawerexample;

import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
//import com.google.maps.android.ui.IconGenerator;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class DistanceDemoActivity extends Fragment implements LocationListener{
    GoogleMap googleMap;
    FragmentManager myFragmentManager;
    SupportMapFragment mySupportMapFragment;
    Polyline mPolyline;

    List<LatLng> lst= new ArrayList<LatLng>();
   private Marker mMarkerA;
    private Marker mMarkerB;
    MapView mapView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.distance_demo, container, false);

        mapView = (MapView) rootView.findViewById(R.id.mapview);
        mapView.onCreate(savedInstanceState);

        // Gets to GoogleMap from the MapView and does initialization stuff
        googleMap = mapView.getMap();
        googleMap.getUiSettings().setMyLocationButtonEnabled(true);
        googleMap.setMyLocationEnabled(true);

        // Needs to call MapsInitializer before doing any CameraUpdateFactory calls
        try {
            MapsInitializer.initialize(this.getActivity());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Updates the location and zoom of the MapView
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(37.2970156, -121.817411), 9);
        googleMap.animateCamera(cameraUpdate);

        return rootView;
    }

    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override
    public void onLocationChanged(Location location) {
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(
                new LatLng(location.getLatitude(), location.getLongitude()), 9);
        googleMap.animateCamera(cameraUpdate);
        lst.add(new LatLng(location.getLatitude(), location.getLongitude()));
      // mPolyline.setPoints(Arrays.asList(lst));
        mPolyline = googleMap.addPolyline(new PolylineOptions().add(new LatLng(location.getLatitude(), location.getLongitude()))
                .width(2)
                .color(Color.BLUE).geodesic(true));
//mPolyline = getMap().addPolyline(new PolylineOptions().add(new LatLng(37.3708905, -121.8675525), new LatLng(37.2970156, -121.827411)));
//mPolyline = getMap().addPolyline(new PolylineOptions().geodesic(true));
        mPolyline.setColor(Color.GREEN);
        mPolyline.setWidth(5);



    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
}
       /* mySupportMapFragment=(SupportMapFragment)getActivity().getSupportFragmentManager().findFragmentById(R.id.map);

        mm=mySupportMapFragment.getMap();
        //googleMap.setMyLocationEnabled(true);
        try {
            initilizeMap();
            googleMap.setMyLocationEnabled(true);
        } catch (Exception e) {
            //e.printStackTrace();
        }
        return rootView;
    }
    private void initilizeMap() {
        try
        {
            if (googleMap == null) {
                myFragmentManager = getActivity().getSupportFragmentManager();
                mySupportMapFragment = (SupportMapFragment)myFragmentManager.findFragmentById(R.id.map);
                googleMap = mySupportMapFragment.getMap();
                //if(googleMap!=null){
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(37.2970156, -121.817411), 9));
                mMarkerA = googleMap.addMarker(new MarkerOptions().position(new LatLng(37.3708905, -121.9675525)));
                mMarkerB = googleMap.addMarker(new MarkerOptions().position(new LatLng(37.2970156, -121.817411)));

                if (googleMap == null) {
                    Toast.makeText(getActivity().getApplicationContext(),
                            "Sorry! unable to create maps", Toast.LENGTH_SHORT)
                            .show();
                }
            }
        } catch (Exception e) {
            Log.i("map", "" +e);
            e.printStackTrace();
            // TODO: handle exception
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        initilizeMap();

    }

    @Override
    public void onDetach() {
        // TODO Auto-generated method stub
        super.onDetach();
        try {
            Field childFragmentManager = Fragment.class
                    .getDeclaredField("mChildFragmentManager");
            childFragmentManager.setAccessible(true);
            childFragmentManager.set(this, null);

        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}*/

