package com.example.navigationdrawerexample;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.List;

import domain.UserPackage;

/**
 * Created by User on 7/27/2015.
 */
public class ChallengeActivity extends Fragment {
   private ListAdapter_Challenge adapter;
    private ListView listView;
    List<UserPackage> users;
    public ChallengeActivity() {

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.challenge_activity, container, false);

        getActivity().setTitle("Challenge Activity");

        ImageView imgView = (ImageView)rootView.findViewById(R.id.challenge_add);
        imgView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Fragment fragment = new CreateChallenge();
                FragmentManager fragmentManager = getActivity().getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();

            }
        });
        listView = (ListView) rootView.findViewById(R.id.challenge_list);
        adapter = new ListAdapter_Challenge(getActivity());
        listView.setAdapter(adapter);
        return rootView;
    }
}
